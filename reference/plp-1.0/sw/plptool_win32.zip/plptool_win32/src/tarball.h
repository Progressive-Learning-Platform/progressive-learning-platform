#ifndef TARBALL_H_
#define TARBALL_H_

#include <fstream>
#include <map>

#include "tarball_sub.h"

class Tarball {
	public:
		/*
		 * Constructor
		 *	Load a tarball file and allow access to the subfiles
		 *	withing the archive
		 */
		Tarball( const char* filename ) : fin(filename) {
		}

		// Open a subfile within the tarball
		TarballSubfile open( const char* filename );
	protected:
		// Read a block of data from file, with the same semantics as the UNIX pread function
		void pread( char* buffer, std::streamsize size, std::streampos from );
	private:
		// File access for the underlying file containing the tarball archive
		std::ifstream fin;

		// Typedef to make iteration types more palletable
		typedef 
			std::map< std::string /* filename */, TarballSubfile* /* subfile */ >
			metadata_cache_t;

		// cache file locations within the tarball to make accessing random files 
		// faster (only have to traverse the file in order once to get all the
		// locations of files and metadata out)
		metadata_cache_t metadata_cache;
		
		// Allow the subfile to access pread
		friend class TarballSubfile;
};

#endif

