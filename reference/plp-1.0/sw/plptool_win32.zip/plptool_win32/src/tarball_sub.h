    #ifndef TARBALL_SUB_H_
#define TARBALL_SUB_H_

// Forward declaration to allow class TarballSubfile to reference objects of 
// type class Tarball
class Tarball;

/*
 * Subfile container for a tarball archive
 */
class TarballSubfile : public std::basic_streambuf<char,std::char_traits<char> >, public std::istream {
	public:
		// Build an object containing a subfile in a tarball archive
		TarballSubfile( Tarball& tar_p, std::streampos start_of_file_p, 
			std::streamsize size_of_file_p, bool valid_p );

		/*
		 * Copy constructor
		 */
		TarballSubfile( const TarballSubfile& other );

		/*
		 * Valid subfile check
		 * Result:
		 *	bool - returns true if the subfile is valid, false otherwise
		 */
		bool operator!() {
			//std::cout << "this->valid = " << (this->valid?"true":"false") << std::endl;
			return !this->valid;
		}
		
		/*
		 * Get the size of the subfile
		 */
		std::streamsize size() {
			return size_of_file;
		}
	protected:
		// Called when the std::streambuf does not have enought bytes in the buffer
		// to fulfill a request
		std::char_traits<char>::int_type underflow();
	private:
		// Parent tarball class holding the archive
		Tarball& tar;

		std::streampos start_of_file;
		std::streamsize size_of_file;

		// Flag determining if this is a valid subfile
		bool valid;

		// Buffer for the stream buffer data
		char buffer[512];

		// Internal read position
		std::streamoff pos;
};

#endif

