#include <iostream>
#include <streambuf>
#include <fstream>
#include <map>
#include <memory>
#include <cassert>
#include <cstring>

#include "tarball.h"

/*
 * Build an object containing a subfile in a tarball archive
 * Parameters:
 *	Tarball& tar_p - a reference to the tarball archive.  
 *		This must remain live for the entire lifetime
 *		the subfile.  Behavior of the subfile is 
 *		undefined if the object passed for this parameter 
 *		ends its lifetime before the subfile
 *	std::streampos start_of_file_p - starting location of the 
 *		subfile within the tarball file.
 *	std::streamsize size_of_file_p - size in bytes of the subfile.
 *	bool valid_p - Determines whether the subfile is valid 
 *		and can be read from.  This is false if the
 */
TarballSubfile::TarballSubfile( Tarball& tar_p, std::streampos start_of_file_p, std::streamsize size_of_file_p, bool valid_p ) 
	: tar(tar_p), start_of_file( start_of_file_p ), size_of_file( size_of_file_p ), std::istream( this )
	, valid(valid_p) 
{
	pos = 0;
}

/*
 * Copy constructor
 */
TarballSubfile::TarballSubfile( const TarballSubfile& other ) 
	: tar( other.tar ), std::istream( this )
	, size_of_file( other.size_of_file ), valid( other.valid ) 
{
	// copy parameters that don't have to be in the initializer list
	start_of_file = other.start_of_file;
	size_of_file = other.size_of_file;
	valid = other.valid;

	// initial parameters
	pos = 0;
}

/* 
 * Called when the std::streambuf does not have enought bytes in the buffer
 * to fulfill a request
 */
std::char_traits<char>::int_type TarballSubfile::underflow() {
	// read up to the length of the file remaining

	std::streamsize len = 512;

    //std::cout << "debug " << size_of_file << " " << pos << std::endl;

	if( ( pos + 512 ) >= size_of_file ) {
    	len = size_of_file - pos;
	}
	

	// End of file condition
	if( len == 0 ) {
		return std::char_traits<char>::eof();
	}

	// Read 512 bytes from the file underlying the tarball archive
	tar.pread( buffer, len, start_of_file + pos );

	// tell the underlying streambuffer what data has been read
	setg(&buffer[0],&buffer[0],&buffer[len]);

    pos += 512;

	// return a char to specify not eof
	return std::char_traits<char>::not_eof(buffer[0]);
}


/*
 * Open a subfile within the tarball
 * Parameters:
 *	const char* filename - the filename of the subfile
 *		to open.
 * Result:
 *	TarballSubfile - a reference to the subfile within
 *		the tar associated with the filename provided
 * Side effects:
 *	In the operation of this function, possibly several
 *	file's metadata will be read from file and cached for
 *	later access in the member `metadata_cache'
 */
TarballSubfile Tarball::open( const char* filename ) {
	/*
	 * Standard POSIX ustar tar header format
	 * Reference:
	 * 	http://people.freebsd.org/~kientzle/libarchive/tar.5.txt
	 */
	struct header_posix_ustar {
		char name[100];
		char mode[8];
		char uid[8];
		char gid[8];
		char size[12];
		char mtime[12];
		char checksum[8];
		char typeflag[1];
		char linkname[100];
		char magic[6];
		char version[2];
		char uname[32];
		char gname[32];
		char devmajor[8];
		char devminor[8];
		char prefix[155];
		char pad[12];
	} header;

	// This caches the result of the string compare between header.magic 
	// and  "ustar"
	bool ustar;

	// This loops until we either find a match to the item or run out of
	// archive to check.  We always check the cache after reading a chunk
	// from the archive and adding it to the cache.  This lets us have only 
	// one piece of code checking for a file name match.
	while(true) {
		// check the metadata cache to see if the file is already known
		metadata_cache_t::iterator pos = metadata_cache.find(filename);
		if( pos != metadata_cache.end() ) {
			return *(pos->second);
		}

		// We have checked the entire file and all of the metadata cache,
		// if we don't have the file now, we never will.  Give a failure
		// condition
		if( fin.eof() ) {
			return TarballSubfile( *this, 0, 0, false );
		}

		// We don't have the metadata in the cache already, start traversing 
		// the archive until we find it, adding metadata to the cache as we 
		// go along, or until we reach the end of the archive file

		// Safety check, make sure we are not reading past the end
		// of the metadata structure
		assert( sizeof(header) == 512 );				

		// Read the archive file header from the archive
		fin.read( (char*)(&(header)), 512 );

		// Ensure that we did indeed read 512 bytes from the file
		if( fin.gcount() != 512 ) {
			// End of file condition
			return TarballSubfile( *this, 0, 0, false );
		}

		// GNU Tar adds extra empty headers after the last valid file, check 
		// to see if we have run into one of those
		if( header.name[0] == '\0' ) {
			return TarballSubfile( *this, 0, 0, false );
		}

		// Check to see if this is a ustar header and set the appropriate 
		// flag in the metadata
		if( memcmp( header.magic, "ustar\0",6)==0 ) {
			ustar = true;
		} else {
			ustar = false;
		}

		// Find out the name of this entry in the archive

		// Make sure that the string is null terminated to prevent reading
		// past the end of the buffer in the case of a malformed archive file
		if( header.name[99] != '\0' ) {
			header.name[99] = '\0';
		}

		// Start building the name from the appropriate field in the old style
		// header format
		std::string filename( header.name );

		// If this is a ustar archive, add the prefix to the beginning of the
		// already decoded pathname
		if( ustar ) {
			// Verify that the prefix field is null terminated
			if( header.prefix[154] != '\0' ) {
				header.prefix[154] = '\0';
			}

			// Add the prefix to the beginning of the filename
			filename = std::string( header.prefix ) + filename;
		}

		// Get the size of the file, the file size field is an octal number encoded
		// in ASCII
		std::streamsize size = 0;
	
		// Convert the octal code into binary
		for( int i = 0; i < 11; ++i ) {
			// Get the character
			char ch = header.size[i];

			// Validate that the character is a valid number
			if( ch >= '0' && ch <= '7' ) {
				// Standard method of converting ASCII to a useable number
				size = size * 8 + ( ch - '0' );
			} else {
				// We have a corrupted field that makes the archive unusable, give up
				throw "Corrupted archive, cannot continue processing";
			}
		}
		//std::cout << filename << " is " << size << " bytes long" << std::endl;

		// Get the current position in the backing file
		std::streampos start = fin.tellg();

		// Add the metadata entry to the cache
		metadata_cache[filename] = new TarballSubfile( *this, start, size, true );

		// Round up to the nearest 512 byte boundary
		if( size % 512 != 0 ) {
			size = size + ( 512 - size % 512 );
		}

		// Seek past the file data
		fin.seekg( size, std::ios_base::cur );
	}
}

/*
 * Read a block of data from file, with the same semantics as the UNIX pread function
 */
void Tarball::pread( char* buffer, std::streamsize size, std::streampos from ) {
	// preserve the previous location of the stream
	std::streampos old_pos = fin.tellg();

	// seek to the position we need to be at
	fin.seekg(from,std::ios_base::beg);

	// read the data from the file
	fin.read( buffer, size );

	// restore the previous location of the stream
	fin.seekg( old_pos, std::ios_base::beg );
}

/*
// Example:
	
int main() {

	try {
		// open the tarball
		Tarball tb("test_files.tar");

		// get the subfile
		TarballSubfile header = tb.open("test_files/header");

		int org;
		header >> org;
		std::cout << "org = " << org << std::endl;

		if( !header ) {
			std::cout << "Unable to open: test_files/header" << std::endl;
			return 1;
		}
	} catch( const char* str ) {
		std::cerr << "Fatal Error: " << str << std::endl;
	}

}
*/
