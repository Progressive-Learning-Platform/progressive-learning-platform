#include <iostream>
#include <fstream>
#include "tarball.h"
#include <windows.h>

using namespace std;

HANDLE open_port(char *port);
void setup_port(HANDLE hSerial);
void write_port(HANDLE hSerial, int len, char* d);
void read_port(HANDLE hSerial, int len, char* d);

void program_PLP0( HANDLE port, std::istream& file, std::streamsize size, uint32_t origin) {
	// make sure that the data ends on a word boundary
	if( size % 4 != 0 ) {
		std::cout << "[e] program binary does not end on a word boundary." << std::endl;
		return;
	}

	// set the program origin
	write_port(port, 1, "o");

	// Convert the machine byte order to PLP-0 byte order
	char word[4];
	word[0] = (origin >> (8*3) ) & 0xFF;
	word[1] = (origin >> (8*2) ) & 0xFF;
	word[2] = (origin >> (8*1) ) & 0xFF;
	word[3] = (origin >> (8*0) ) & 0xFF;
	write_port(port,4,word);

	// Programming progress
	std::cout << "[i] programming...";

	// program each byte
	for( std::streamsize i = 0; i < size; i += 4 ) {
		// Each word is stored as a 32-bit value with most significant byte first (Big-Endian)
        file.read(word,4);
    
        uint32_t *d = (uint32_t*)word;
        //std::cout << "[i] " << i << " - "<< std::hex << *d << std::endl;
		
		// Write the word to the board
		write_port(port,1,"d");
		write_port(port,4,word);

		// Programming progress
		std::cout << "." << std::flush;
	}

	// Programming progress
	std::cout << "done." << std::endl;
}


int main( int argc, char* argv[] ) {
	// Check program arguments
	if( argc != 2 ) {
		std::cerr << "[e] usage: " << argv[0] << " <filename>" << std::endl;
		return 1;
	}

    std::cout << "[w] plptool_win32 - david fritz - 'i can't believe i wrote a win32 app'" << std::endl;
    std::cout << "[w] bug #1: bad serial code made things way too slow - so fritz rewrote it." << std::endl;
    std::cout << "[w] bug #2: pos += 512; found missing? " << std::endl;

	// Open the tarball containing the programming files
	Tarball tb( argv[1] );
	
	// Open the header file and ensure that it loaded
	TarballSubfile header = tb.open("header.mcasm" );
	if( !header ) {
		std::cerr << "[e] invalid plp file" << std::endl;
		return 1;
	}

	// Read the origin address from the header file
	uint32_t org;
	header >> org;

	// Debug: Display the program origin
	std::cout << "[i] org: " << std::hex << org << std::endl;

	// Read the name of the program data in the archive
	std::string program_file;
	header >> program_file;

	// Debug: Display the name of the program file
	std::cout << "[i] program filename: `" << program_file << "'" << std::endl;

	// Open the program data file and make sure it loads
	TarballSubfile program_data = tb.open( program_file.c_str() );
	if( !program_data ) {
		std::cout << "[e] unable to open program data file" << std::endl;
		return 1;
	}

	// Debug: Display the number of words to program
	std::cout << "[i] file size: " << std::hex << program_data.size() << std::endl;

	// Autodetect the COMM port
	for( int i = 1; i < 30; ++i ) {
		
		// try to open the COMM port
		char s[10];
		sprintf(s,"COM%d",i);
		HANDLE port = open_port(s);
		
		// Try the next port if we couldn't open it
		if( port != NULL ) {
			std::cout << "[i] opened COM" << i << std::endl;
		
		    setup_port(port);
		
			// Try to autodetect the board device
			write_port(port,1,"i");
			
			char buffer[5];
			buffer[4] = '\0';
			read_port(port,4,buffer);
			if( strcmp(buffer,"plp0")==0) {
				std::cout << "[i] detected PLP-0 bootloader" << std::endl;
				program_PLP0( port, program_data, program_data.size(), org );
				
				// Pause, then exit
				std::cout << "[i] waiting for user input to start program" << std::endl;
                system("PAUSE");
				
				// Start the program
            	write_port(port,1,"j");
				
                CloseHandle(port);
				
				return 0;
			} else {
				std::cout << "[e] id: " << buffer << std::endl;
			}
		}
	}
	
	std::cerr << "[e] no available com ports found" << std::endl;
    return 0;
}

HANDLE open_port(char *port) {
    HANDLE hSerial;
    hSerial=CreateFile(port,
                              GENERIC_READ|GENERIC_WRITE,
                              0,
                              0,
                              OPEN_EXISTING,
                              FILE_ATTRIBUTE_NORMAL,
                              0);
    if(hSerial==INVALID_HANDLE_VALUE){
         if(GetLastError()==ERROR_FILE_NOT_FOUND){
             return NULL;
         }
         return NULL;
    }
    return hSerial;
}

void setup_port(HANDLE hSerial) {
    DCB dcbSerialParams={0};
    dcbSerialParams.DCBlength=sizeof(dcbSerialParams);
    GetCommState(hSerial,&dcbSerialParams);
    
    dcbSerialParams.BaudRate=CBR_9600;
    dcbSerialParams.ByteSize=8;
    dcbSerialParams.StopBits=ONESTOPBIT;
    dcbSerialParams.Parity=NOPARITY;
    SetCommState(hSerial,&dcbSerialParams);
    
    COMMTIMEOUTS timeouts={0};
    timeouts.ReadIntervalTimeout=50;
    timeouts.ReadTotalTimeoutConstant=50;
    timeouts.ReadTotalTimeoutMultiplier=10;
    timeouts.WriteTotalTimeoutConstant=50;
    timeouts.WriteTotalTimeoutMultiplier=10;
    SetCommTimeouts(hSerial,&timeouts);
}

void write_port(HANDLE hSerial, int len, char* d) {
     DWORD bytes;
     WriteFile(hSerial,d,len,&bytes,NULL);
}

void read_port(HANDLE hSerial, int len, char* d) {
     DWORD bytes;
     ReadFile(hSerial,d,len,&bytes,NULL);
}
